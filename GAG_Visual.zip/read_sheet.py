import gspread

gc = gspread.service_account(filename="/home/ubuntu/upload/gag-visual-automacao-0ed0178a3271.json")
spreadsheet = gc.open("Pedidos_GAG_Visual")
worksheet = spreadsheet.sheet1

# Obter todos os valores da planilha
list_of_rows = worksheet.get_all_values()

# Imprimir as últimas 5 linhas para verificar a adição
for row in list_of_rows[-5:]:
    print(row)


