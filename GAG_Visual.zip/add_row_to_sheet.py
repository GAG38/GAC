import gspread

# Use as credenciais da conta de serviço
gc = gspread.service_account(filename="/home/ubuntu/upload/gag-visual-automacao-0ed0178a3271.json")

# Abra a planilha pelo nome
spreadsheet = gc.open("Pedidos_GAG_Visual")

# Selecione a primeira aba (worksheet)
worksheet = spreadsheet.sheet1

# Dados a serem adicionados
row_data = ["Teste Direto Manus", "Automação Final", "1000"]

# Adicione a nova linha
worksheet.append_row(row_data)

print("Linha adicionada com sucesso!")


